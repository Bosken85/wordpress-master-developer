<?php
/**
 * WordPress Master Developer Theme functions - Minimal version for testing
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Theme setup
function wp_master_dev_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'wp_master_dev_setup' );

// Enqueue styles and scripts
function wp_master_dev_scripts() {
    wp_enqueue_style( 'wp-master-dev-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'wp_master_dev_scripts' );

// Enqueue Bootstrap and theme styles
function wp_master_dev_enqueue_assets() {
    // Bootstrap CSS from CDN
    wp_enqueue_style( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css', array(), '5.3.0' );
    
    // Theme main CSS
    wp_enqueue_style( 'wp-master-dev-main', get_template_directory_uri() . '/assets/css/main.css', array('bootstrap'), '1.0.0' );
    
    // Bootstrap JavaScript from CDN
    wp_enqueue_script( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js', array(), '5.3.0', true );
    
    // Theme JavaScript
    if ( file_exists( get_template_directory() . '/assets/js/main.js' ) ) {
        wp_enqueue_script( 'wp-master-dev-main', get_template_directory_uri() . '/assets/js/main.js', array('bootstrap'), '1.0.0', true );
    }
    
    if ( file_exists( get_template_directory() . '/assets/js/navigation.js' ) ) {
        wp_enqueue_script( 'wp-master-dev-nav', get_template_directory_uri() . '/assets/js/navigation.js', array(), '1.0.0', true );
    }
}
add_action( 'wp_enqueue_scripts', 'wp_master_dev_enqueue_assets' );

// Add Font Awesome for icons
function wp_master_dev_add_fontawesome() {
    wp_enqueue_style( 'fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0' );
}
add_action( 'wp_enqueue_scripts', 'wp_master_dev_add_fontawesome' );

/**
 * Theme Setup Wizard
 */
require_once get_template_directory() . '/inc/theme-installer.php';

// Add admin menu for wizard
function wp_master_dev_add_wizard_menu() {
    add_theme_page(
        'Theme Setup Wizard',
        'Setup Wizard',
        'manage_options',
        'wp-master-dev-wizard',
        'wp_master_dev_wizard_page'
    );
}
add_action('admin_menu', 'wp_master_dev_add_wizard_menu');

// Wizard page callback
function wp_master_dev_wizard_page() {
    if (class_exists('WP_Master_Dev_Theme_Installer')) {
        $installer = new WP_Master_Dev_Theme_Installer();
        $installer->render_wizard();
    }
}

// Enqueue wizard assets
function wp_master_dev_wizard_assets($hook) {
    if ($hook !== 'appearance_page_wp-master-dev-wizard') {
        return;
    }
    
    wp_enqueue_style('wp-master-dev-wizard-css', get_template_directory_uri() . '/assets/css/wizard.css', array(), '1.0.0');
    wp_enqueue_script('wp-master-dev-wizard-js', get_template_directory_uri() . '/assets/js/wizard.js', array('jquery'), '1.0.0', true);
    
    // Localize script
    wp_localize_script('wp-master-dev-wizard-js', 'wpMasterDevWizard', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('wp_master_dev_wizard_nonce'),
        'strings' => array(
            'error' => __('An error occurred. Please try again.', 'wp-master-dev'),
            'success' => __('Settings saved successfully!', 'wp-master-dev'),
            'processing' => __('Processing...', 'wp-master-dev')
        )
    ));
}
add_action('admin_enqueue_scripts', 'wp_master_dev_wizard_assets');

// AJAX handler for wizard steps
function wp_master_dev_wizard_step_handler() {
    check_ajax_referer('wp_master_dev_wizard_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $step = intval($_POST['step']);
    $data = $_POST['data'];
    
    if (class_exists('WP_Master_Dev_Theme_Installer')) {
        $installer = new WP_Master_Dev_Theme_Installer();
        $result = $installer->process_step($step, $data);
        
        if ($result) {
            wp_send_json_success(array('message' => __('Step completed successfully!', 'wp-master-dev')));
        } else {
            wp_send_json_error(array('message' => __('Failed to complete step.', 'wp-master-dev')));
        }
    }
    
    wp_send_json_error(array('message' => __('Installer class not found.', 'wp-master-dev')));
}
add_action('wp_ajax_wp_master_dev_wizard_step', 'wp_master_dev_wizard_step_handler');

// Show wizard notice after theme activation
function wp_master_dev_activation_notice() {
    if (get_option('wp_master_dev_wizard_completed')) {
        return;
    }
    
    $wizard_url = admin_url('themes.php?page=wp-master-dev-wizard');
    ?>
    <div class="notice notice-info is-dismissible">
        <p>
            <strong><?php _e('Welcome to WordPress Master Developer Theme!', 'wp-master-dev'); ?></strong>
            <?php _e('Complete the setup wizard to get started quickly.', 'wp-master-dev'); ?>
            <a href="<?php echo esc_url($wizard_url); ?>" class="button button-primary" style="margin-left: 10px;">
                <?php _e('Run Setup Wizard', 'wp-master-dev'); ?>
            </a>
        </p>
    </div>
    <?php
}
add_action('admin_notices', 'wp_master_dev_activation_notice');
