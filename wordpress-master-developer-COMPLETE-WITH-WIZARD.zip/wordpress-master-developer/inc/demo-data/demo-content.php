<?php
/**
 * Demo Content Data for WordPress Master Developer Theme
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Master_Dev_Demo_Content {
    
    public static function get_demo_posts() {
        return array(
            array(
                'post_title' => 'Custom WordPress Development Services',
                'post_content' => '<p>Transform your business with custom WordPress solutions tailored to your unique needs. Our expert development team specializes in creating high-performance, scalable WordPress websites that drive results.</p>

<h2>What We Offer</h2>
<ul>
<li>Custom Theme Development</li>
<li>Plugin Development & Customization</li>
<li>E-commerce Solutions with WooCommerce</li>
<li>Performance Optimization</li>
<li>Security Hardening</li>
<li>Ongoing Maintenance & Support</li>
</ul>

<p>With over 10 years of experience in WordPress development, we understand what it takes to build websites that not only look great but perform exceptionally well in search engines and convert visitors into customers.</p>

<blockquote>
<p>"The team delivered exactly what we needed - a fast, secure, and beautiful WordPress site that has increased our conversions by 40%." - Sarah Johnson, CEO</p>
</blockquote>

<p>Ready to take your WordPress site to the next level? Contact us today for a free consultation and discover how we can help transform your online presence.</p>',
                'post_status' => 'publish',
                'post_type' => 'post',
                'post_category' => array('WordPress Development'),
                'meta_input' => array(
                    '_featured_post' => 'yes'
                )
            ),
            array(
                'post_title' => 'WordPress Performance Optimization: Speed Up Your Site',
                'post_content' => '<p>Is your WordPress site running slowly? Page speed is crucial for user experience and SEO rankings. Learn how our optimization techniques can make your site lightning fast.</p>

<h2>Performance Optimization Techniques</h2>
<p>We employ a comprehensive approach to WordPress performance optimization:</p>

<h3>1. Code Optimization</h3>
<ul>
<li>Minify CSS, JavaScript, and HTML</li>
<li>Optimize database queries</li>
<li>Remove unused plugins and themes</li>
<li>Clean up WordPress database</li>
</ul>

<h3>2. Caching Solutions</h3>
<ul>
<li>Browser caching configuration</li>
<li>Server-side caching implementation</li>
<li>CDN integration for global performance</li>
<li>Object caching for dynamic content</li>
</ul>

<h3>3. Image Optimization</h3>
<ul>
<li>WebP format conversion</li>
<li>Lazy loading implementation</li>
<li>Responsive image delivery</li>
<li>Compression without quality loss</li>
</ul>

<p>Our clients typically see 50-80% improvement in page load times after our optimization process. This translates to better user experience, higher search rankings, and increased conversions.</p>',
                'post_status' => 'publish',
                'post_type' => 'post',
                'post_category' => array('Performance', 'WordPress Development')
            ),
            array(
                'post_title' => 'WordPress Security Best Practices for 2024',
                'post_content' => '<p>Protect your WordPress website from security threats with our comprehensive security hardening services. Learn about the latest security best practices and how to implement them.</p>

<h2>Essential Security Measures</h2>

<h3>1. Core Security Hardening</h3>
<ul>
<li>Regular WordPress core updates</li>
<li>Strong password policies</li>
<li>Two-factor authentication</li>
<li>Limited login attempts</li>
<li>Hide WordPress version information</li>
</ul>

<h3>2. Plugin and Theme Security</h3>
<ul>
<li>Regular updates and security patches</li>
<li>Code review and vulnerability scanning</li>
<li>Remove unused plugins and themes</li>
<li>Use reputable sources only</li>
</ul>

<h3>3. Server-Level Security</h3>
<ul>
<li>SSL certificate implementation</li>
<li>Firewall configuration</li>
<li>Regular security monitoring</li>
<li>Automated backups</li>
<li>Malware scanning and removal</li>
</ul>

<p>Security is not a one-time setup but an ongoing process. Our security maintenance plans ensure your WordPress site stays protected against the latest threats.</p>

<p><strong>Contact us today</strong> to schedule a comprehensive security audit of your WordPress website.</p>',
                'post_status' => 'publish',
                'post_type' => 'post',
                'post_category' => array('Security', 'WordPress Development')
            )
        );
    }
    
    public static function get_demo_pages() {
        return array(
            'about' => array(
                'post_title' => 'About Us',
                'post_content' => '<div class="hero-section">
<h1>WordPress Development Experts</h1>
<p class="lead">With over a decade of experience, we are passionate WordPress developers dedicated to creating exceptional digital experiences that drive business growth.</p>
</div>

<div class="about-content">
<h2>Our Story</h2>
<p>Founded in 2014, our journey began with a simple mission: to help businesses succeed online through powerful, custom WordPress solutions. What started as a small team of developers has grown into a full-service WordPress development agency trusted by hundreds of clients worldwide.</p>

<h2>Our Expertise</h2>
<div class="expertise-grid">
<div class="expertise-item">
<h3>Custom Development</h3>
<p>Tailored WordPress solutions built from the ground up to meet your specific business requirements.</p>
</div>
<div class="expertise-item">
<h3>Performance Optimization</h3>
<p>Lightning-fast websites that provide exceptional user experience and rank higher in search engines.</p>
</div>
<div class="expertise-item">
<h3>Security & Maintenance</h3>
<p>Comprehensive security hardening and ongoing maintenance to keep your site safe and up-to-date.</p>
</div>
<div class="expertise-item">
<h3>E-commerce Solutions</h3>
<p>Powerful WooCommerce stores that convert visitors into customers and drive revenue growth.</p>
</div>
</div>

<h2>Why Choose Us?</h2>
<ul>
<li><strong>10+ Years Experience:</strong> Deep expertise in WordPress development and best practices</li>
<li><strong>Custom Solutions:</strong> No cookie-cutter approaches - every project is unique</li>
<li><strong>Performance Focus:</strong> Fast, optimized websites that users and search engines love</li>
<li><strong>Ongoing Support:</strong> Comprehensive maintenance and support services</li>
<li><strong>Proven Results:</strong> Hundreds of successful projects and satisfied clients</li>
</ul>

<h2>Our Values</h2>
<p>We believe in transparency, quality, and building long-term relationships with our clients. Every project we undertake is treated with the same level of care and attention to detail, regardless of size or budget.</p>

<p><strong>Ready to work with us?</strong> Contact our team today to discuss your WordPress development needs.</p>
</div>',
                'post_status' => 'publish',
                'post_type' => 'page'
            ),
            'services' => array(
                'post_title' => 'Services',
                'post_content' => '<div class="services-hero">
<h1>WordPress Development Services</h1>
<p class="lead">Comprehensive WordPress solutions to power your business growth and online success.</p>
</div>

<div class="services-grid">
<div class="service-item featured">
<h2>Custom WordPress Development</h2>
<p>Tailored WordPress websites built from scratch to meet your unique business requirements and goals.</p>
<ul>
<li>Custom theme development</li>
<li>Plugin development and customization</li>
<li>API integrations</li>
<li>Database optimization</li>
<li>Responsive design implementation</li>
</ul>
<div class="service-pricing">
<span class="price">Starting at $2,500</span>
<a href="/contact" class="btn btn-primary">Get Quote</a>
</div>
</div>

<div class="service-item">
<h2>WordPress Performance Optimization</h2>
<p>Speed up your WordPress site with our comprehensive performance optimization services.</p>
<ul>
<li>Page speed optimization</li>
<li>Caching implementation</li>
<li>Image optimization</li>
<li>Code minification</li>
<li>CDN setup and configuration</li>
</ul>
<div class="service-pricing">
<span class="price">Starting at $800</span>
<a href="/contact" class="btn btn-primary">Get Quote</a>
</div>
</div>

<div class="service-item">
<h2>WordPress Security & Maintenance</h2>
<p>Keep your WordPress site secure, updated, and running smoothly with our maintenance services.</p>
<ul>
<li>Security hardening</li>
<li>Regular updates and backups</li>
<li>Malware scanning and removal</li>
<li>Uptime monitoring</li>
<li>Performance monitoring</li>
</ul>
<div class="service-pricing">
<span class="price">$150/month</span>
<a href="/contact" class="btn btn-primary">Get Started</a>
</div>
</div>

<div class="service-item">
<h2>WooCommerce Development</h2>
<p>Powerful e-commerce solutions built on WooCommerce to drive your online sales.</p>
<ul>
<li>Custom WooCommerce themes</li>
<li>Payment gateway integration</li>
<li>Inventory management systems</li>
<li>Custom checkout processes</li>
<li>Third-party integrations</li>
</ul>
<div class="service-pricing">
<span class="price">Starting at $3,500</span>
<a href="/contact" class="btn btn-primary">Get Quote</a>
</div>
</div>
</div>

<div class="process-section">
<h2>Our Development Process</h2>
<div class="process-steps">
<div class="process-step">
<div class="step-number">1</div>
<h3>Discovery & Planning</h3>
<p>We start by understanding your business goals, target audience, and technical requirements.</p>
</div>
<div class="process-step">
<div class="step-number">2</div>
<h3>Design & Development</h3>
<p>Our team creates custom designs and develops your WordPress solution using best practices.</p>
</div>
<div class="process-step">
<div class="step-number">3</div>
<h3>Testing & Optimization</h3>
<p>Comprehensive testing ensures your site performs flawlessly across all devices and browsers.</p>
</div>
<div class="process-step">
<div class="step-number">4</div>
<h3>Launch & Support</h3>
<p>We handle the launch process and provide ongoing support to ensure continued success.</p>
</div>
</div>
</div>',
                'post_status' => 'publish',
                'post_type' => 'page'
            ),
            'contact' => array(
                'post_title' => 'Contact',
                'post_content' => '<div class="contact-hero">
<h1>Get In Touch</h1>
<p class="lead">Ready to start your WordPress project? Contact our team for a free consultation and discover how we can help transform your online presence.</p>
</div>

<div class="contact-content">
<div class="contact-form-section">
<h2>Send Us a Message</h2>
<form class="contact-form" method="post" action="">
<div class="form-row">
<div class="form-group">
<label for="name">Full Name *</label>
<input type="text" id="name" name="name" required>
</div>
<div class="form-group">
<label for="email">Email Address *</label>
<input type="email" id="email" name="email" required>
</div>
</div>
<div class="form-group">
<label for="company">Company Name</label>
<input type="text" id="company" name="company">
</div>
<div class="form-group">
<label for="phone">Phone Number</label>
<input type="tel" id="phone" name="phone">
</div>
<div class="form-group">
<label for="service">Service Interested In</label>
<select id="service" name="service">
<option value="">Select a service</option>
<option value="custom-development">Custom WordPress Development</option>
<option value="performance-optimization">Performance Optimization</option>
<option value="security-maintenance">Security & Maintenance</option>
<option value="woocommerce">WooCommerce Development</option>
<option value="other">Other</option>
</select>
</div>
<div class="form-group">
<label for="budget">Project Budget</label>
<select id="budget" name="budget">
<option value="">Select budget range</option>
<option value="under-1k">Under $1,000</option>
<option value="1k-5k">$1,000 - $5,000</option>
<option value="5k-10k">$5,000 - $10,000</option>
<option value="10k-25k">$10,000 - $25,000</option>
<option value="25k-plus">$25,000+</option>
</select>
</div>
<div class="form-group">
<label for="message">Project Details *</label>
<textarea id="message" name="message" rows="6" placeholder="Tell us about your project requirements, goals, and timeline..." required></textarea>
</div>
<button type="submit" class="btn btn-primary btn-large">Send Message</button>
</form>
</div>

<div class="contact-info-section">
<h2>Contact Information</h2>
<div class="contact-info">
<div class="contact-item">
<h3>Email</h3>
<p><a href="mailto:hello@wordpressmasterdev.com">hello@wordpressmasterdev.com</a></p>
</div>
<div class="contact-item">
<h3>Phone</h3>
<p><a href="tel:+1234567890">+1 (234) 567-890</a></p>
</div>
<div class="contact-item">
<h3>Office Hours</h3>
<p>Monday - Friday: 9:00 AM - 6:00 PM EST<br>
Saturday: 10:00 AM - 4:00 PM EST<br>
Sunday: Closed</p>
</div>
<div class="contact-item">
<h3>Response Time</h3>
<p>We typically respond to all inquiries within 24 hours during business days.</p>
</div>
</div>

<h2>Frequently Asked Questions</h2>
<div class="faq-section">
<div class="faq-item">
<h3>How long does a typical WordPress project take?</h3>
<p>Project timelines vary based on complexity, but most custom WordPress sites take 4-8 weeks from start to finish.</p>
</div>
<div class="faq-item">
<h3>Do you provide ongoing maintenance?</h3>
<p>Yes, we offer comprehensive maintenance plans starting at $150/month to keep your site secure and up-to-date.</p>
</div>
<div class="faq-item">
<h3>Can you work with existing WordPress sites?</h3>
<p>Absolutely! We can optimize, redesign, or add functionality to existing WordPress websites.</p>
</div>
<div class="faq-item">
<h3>What is your payment structure?</h3>
<p>We typically require 50% upfront and 50% upon project completion. Monthly maintenance is billed in advance.</p>
</div>
</div>
</div>
</div>',
                'post_status' => 'publish',
                'post_type' => 'page'
            )
        );
    }
    
    public static function get_customizer_defaults() {
        return array(
            'hero_title' => 'WordPress Master Developer',
            'hero_subtitle' => 'Expert WordPress Development Services',
            'hero_description' => 'Transform your business with custom WordPress solutions. We create high-performance, scalable websites that drive results and exceed expectations.',
            'hero_button_text' => 'Get Started Today',
            'hero_button_url' => '/contact',
            'company_name' => 'WordPress Master Developer',
            'company_email' => 'hello@wordpressmasterdev.com',
            'company_phone' => '+1 (234) 567-890',
            'company_address' => '123 Developer Street, Tech City, TC 12345',
            'social_facebook' => 'https://facebook.com/wordpressmasterdev',
            'social_twitter' => 'https://twitter.com/wordpressmasterdev',
            'social_linkedin' => 'https://linkedin.com/company/wordpressmasterdev',
            'social_github' => 'https://github.com/wordpressmasterdev'
        );
    }
}
