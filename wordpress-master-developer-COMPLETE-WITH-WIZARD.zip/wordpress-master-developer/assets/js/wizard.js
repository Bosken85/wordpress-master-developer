/**
 * WordPress Master Developer Theme Setup Wizard JavaScript
 */

(function($) {
    'use strict';

    var WPMasterDevWizard = {
        currentStep: 1,
        totalSteps: 6,
        
        init: function() {
            this.bindEvents();
            this.updateProgress();
        },
        
        bindEvents: function() {
            var self = this;
            
            // Next step buttons
            $(document).on('click', '.next-step', function(e) {
                e.preventDefault();
                var nextStep = parseInt($(this).data('next'));
                self.processStep(nextStep);
            });
            
            // Previous step buttons
            $(document).on('click', '.prev-step', function(e) {
                e.preventDefault();
                var prevStep = parseInt($(this).data('prev'));
                self.goToStep(prevStep);
            });
            
            // Step navigation
            $(document).on('click', '.progress-steps .step', function(e) {
                e.preventDefault();
                var step = parseInt($(this).data('step'));
                if (step <= self.currentStep) {
                    self.goToStep(step);
                }
            });
        },
        
        processStep: function(nextStep) {
            var self = this;
            var currentStepData = this.getCurrentStepData();
            
            if (nextStep > 1 && nextStep <= 6) {
                this.showLoading();
                
                // Send AJAX request to process current step
                $.ajax({
                    url: wpMasterDevWizard.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'wp_master_dev_wizard_step',
                        step: this.currentStep,
                        data: currentStepData,
                        nonce: wpMasterDevWizard.nonce
                    },
                    success: function(response) {
                        self.hideLoading();
                        if (response.success) {
                            self.goToStep(nextStep);
                        } else {
                            self.showError(response.data.message || wpMasterDevWizard.strings.error);
                        }
                    },
                    error: function() {
                        self.hideLoading();
                        self.showError(wpMasterDevWizard.strings.error);
                    }
                });
            } else {
                this.goToStep(nextStep);
            }
        },
        
        goToStep: function(step) {
            // Hide all steps
            $('.wizard-step').removeClass('active');
            
            // Show target step
            $('.wizard-step[data-step="' + step + '"]').addClass('active');
            
            // Update current step
            this.currentStep = step;
            
            // Update progress
            this.updateProgress();
            
            // Update step indicators
            this.updateStepIndicators();
        },
        
        updateProgress: function() {
            var progress = ((this.currentStep - 1) / (this.totalSteps - 1)) * 100;
            $('.progress-fill').css('width', progress + '%');
        },
        
        updateStepIndicators: function() {
            $('.progress-steps .step').each(function() {
                var stepNum = parseInt($(this).data('step'));
                $(this).removeClass('active completed');
                
                if (stepNum < WPMasterDevWizard.currentStep) {
                    $(this).addClass('completed');
                } else if (stepNum === WPMasterDevWizard.currentStep) {
                    $(this).addClass('active');
                }
            });
        },
        
        getCurrentStepData: function() {
            var data = {};
            var currentStepEl = $('.wizard-step[data-step="' + this.currentStep + '"]');
            
            // Collect form data based on current step
            switch (this.currentStep) {
                case 2: // Pages
                    data.create_pages = [];
                    currentStepEl.find('input[name="create_pages[]"]:checked').each(function() {
                        data.create_pages.push($(this).val());
                    });
                    break;
                    
                case 3: // Menus
                    data.create_menus = [];
                    currentStepEl.find('input[name="create_menus[]"]:checked').each(function() {
                        data.create_menus.push($(this).val());
                    });
                    break;
                    
                case 4: // Content
                    data.import_content = [];
                    currentStepEl.find('input[name="import_content[]"]:checked').each(function() {
                        data.import_content.push($(this).val());
                    });
                    break;
                    
                case 5: // Customize
                    currentStepEl.find('input, textarea').each(function() {
                        if ($(this).attr('name')) {
                            data[$(this).attr('name')] = $(this).val();
                        }
                    });
                    break;
            }
            
            return data;
        },
        
        showLoading: function() {
            $('.wizard-loading').show();
        },
        
        hideLoading: function() {
            $('.wizard-loading').hide();
        },
        
        showError: function(message) {
            // Remove existing messages
            $('.wizard-message').remove();
            
            // Add error message
            var errorHtml = '<div class="wizard-message error">' + message + '</div>';
            $('.wizard-step.active .step-content').prepend(errorHtml);
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                $('.wizard-message').fadeOut();
            }, 5000);
        },
        
        showSuccess: function(message) {
            // Remove existing messages
            $('.wizard-message').remove();
            
            // Add success message
            var successHtml = '<div class="wizard-message success">' + message + '</div>';
            $('.wizard-step.active .step-content').prepend(successHtml);
            
            // Auto-hide after 3 seconds
            setTimeout(function() {
                $('.wizard-message').fadeOut();
            }, 3000);
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        if ($('.wp-master-dev-wizard').length) {
            WPMasterDevWizard.init();
        }
    });
    
    // Make it globally accessible
    window.WPMasterDevWizard = WPMasterDevWizard;

})(jQuery);
