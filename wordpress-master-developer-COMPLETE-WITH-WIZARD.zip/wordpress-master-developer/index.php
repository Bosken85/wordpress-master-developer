<?php
/**
 * The main template file
 *
 * @package WordPress_Master_Developer
 * @since 1.0.0
 */

get_header(); ?>

<?php if (is_home() && is_front_page()) : ?>
    <!-- Hero Section -->
    <section class="hero-section position-relative overflow-hidden">
        <div class="hero-background position-absolute w-100 h-100">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero-bg.png" alt="Hero Background" class="w-100 h-100 object-fit-cover">
        </div>
        <div class="container position-relative">
            <div class="row min-vh-100 align-items-center">
                <div class="col-lg-8">
                    <div class="hero-content text-white">
                        <h1 class="display-4 fw-bold mb-4">WordPress Master Developer</h1>
                        <p class="lead mb-4">Expert WordPress theme development from scratch</p>
                        <p class="mb-5">Deep expertise in PHP, CSS, HTML, and JavaScript. Creating high-quality, performance-optimized WordPress themes that are fully integrated with WordPress core and built for security, scalability, and upgrade safety.</p>
                        <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="btn btn-primary btn-lg">Start Your Project</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-5">
                    <h2 class="display-5 fw-bold">Our Services</h2>
                    <p class="lead">Professional WordPress development services</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-3">
                                <i class="fas fa-code fa-3x text-primary"></i>
                            </div>
                            <h5 class="card-title">Custom Theme Development</h5>
                            <p class="card-text">Build custom WordPress themes from scratch tailored to your specific needs.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-3">
                                <i class="fas fa-mobile-alt fa-3x text-primary"></i>
                            </div>
                            <h5 class="card-title">Responsive Design</h5>
                            <p class="card-text">Ensure your website looks perfect on all devices and screen sizes.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-3">
                                <i class="fas fa-tachometer-alt fa-3x text-primary"></i>
                            </div>
                            <h5 class="card-title">Performance Optimization</h5>
                            <p class="card-text">Optimize your WordPress site for speed and search engine rankings.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-3">
                                <i class="fas fa-shield-alt fa-3x text-primary"></i>
                            </div>
                            <h5 class="card-title">Security & Maintenance</h5>
                            <p class="card-text">Keep your WordPress site secure and up-to-date with regular maintenance.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php else : ?>
    <div class="container">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article class="mb-5">
                    <h1><?php the_title(); ?></h1>
                    <div><?php the_content(); ?></div>
                </article>
            <?php endwhile; ?>
        <?php else : ?>
            <p>No content found.</p>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php get_footer(); ?>
