    <footer id="colophon" class="site-footer">
        <p>&copy; <?php echo date('Y'); ?> WordPress Master Developer</p>
    </footer>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
