<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm">
        <div class="container">
            <!-- Logo -->
            <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <?php if ( has_custom_logo() ) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="<?php bloginfo( 'name' ); ?>" style="height: 80px; width: auto;">
                <?php endif; ?>
            </a>

            <!-- Desktop Navigation -->
            <div class="collapse navbar-collapse d-none d-lg-flex" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo esc_url( home_url( '/about' ) ); ?>">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo esc_url( home_url( '/services' ) ); ?>">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a>
                    </li>
                </ul>
                <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="btn btn-primary">Get Started</a>
            </div>

            <!-- Mobile Hamburger Button -->
            <button class="navbar-toggler d-lg-none" type="button" id="mobile-menu-toggle">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>

    <!-- Mobile Menu Overlay -->
    <div class="mobile-menu-overlay" id="mobile-menu-overlay">
        <div class="mobile-menu-content">
            <div class="mobile-menu-header">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="<?php bloginfo( 'name' ); ?>" style="height: 40px;">
                <button class="mobile-menu-close" id="mobile-menu-close">&times;</button>
            </div>
            <nav class="mobile-menu-nav">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mobile-menu-link">Home</a>
                <a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="mobile-menu-link">About</a>
                <a href="<?php echo esc_url( home_url( '/services' ) ); ?>" class="mobile-menu-link">Services</a>
                <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="mobile-menu-link">Contact</a>
                <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="btn btn-primary w-100 mt-4">Get Started</a>
            </nav>
        </div>
    </div>

    <main id="main" class="site-main" style="padding-top: 100px;">
