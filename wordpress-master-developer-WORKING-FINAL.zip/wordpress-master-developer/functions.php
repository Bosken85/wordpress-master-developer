<?php
/**
 * WordPress Master Developer Theme functions - Minimal version for testing
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Theme setup
function wp_master_dev_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'wp_master_dev_setup' );

// Enqueue styles and scripts
function wp_master_dev_scripts() {
    wp_enqueue_style( 'wp-master-dev-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'wp_master_dev_scripts' );

// Enqueue Bootstrap and theme styles
function wp_master_dev_enqueue_assets() {
    // Bootstrap CSS from CDN
    wp_enqueue_style( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css', array(), '5.3.0' );
    
    // Theme main CSS
    wp_enqueue_style( 'wp-master-dev-main', get_template_directory_uri() . '/assets/css/main.css', array('bootstrap'), '1.0.0' );
    
    // Bootstrap JavaScript from CDN
    wp_enqueue_script( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js', array(), '5.3.0', true );
    
    // Theme JavaScript
    if ( file_exists( get_template_directory() . '/assets/js/main.js' ) ) {
        wp_enqueue_script( 'wp-master-dev-main', get_template_directory_uri() . '/assets/js/main.js', array('bootstrap'), '1.0.0', true );
    }
    
    if ( file_exists( get_template_directory() . '/assets/js/navigation.js' ) ) {
        wp_enqueue_script( 'wp-master-dev-nav', get_template_directory_uri() . '/assets/js/navigation.js', array(), '1.0.0', true );
    }
}
add_action( 'wp_enqueue_scripts', 'wp_master_dev_enqueue_assets' );

// Add Font Awesome for icons
function wp_master_dev_add_fontawesome() {
    wp_enqueue_style( 'fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0' );
}
add_action( 'wp_enqueue_scripts', 'wp_master_dev_add_fontawesome' );
